# portifolio

Portifolio do desenvolvedor

## Tarefas

O controle das tarefas desse projeto será realizado no GitHub

## Ícones

- :package: nova funcionalidade
- :up: atualização
- :beetle: correção de bug
- :checkered_flag: release
